#!/bin/bash
#echo "OPT student"
#python ILP_student_max.py
TIMEFORMAT=%R
echo "OPT, none, student, augmenting" > log
#for ((i=1;i<=49;i=$i+1)); do
#	python generate.py $i
#	for ((j=1;j<=15;j=$j+1)); do
#		echo "$i $j" | tee -a log
#		#echo "OPT course"
#		{ time python ILP_student_max.py >> log ; } 2>>log 
#		#echo "none"
#		{ time python approx.py >> log ; } 2>>log 
#		#echo "student"
#		{ time python studentdeg.py >> log ; } 2>>log 
#		#echo "augmenting"
#		{ time python augmenting.py >> log ; } 2>>log 
#	done
#done
for ((i=20;i<=100;i=$i+10)); do
	python generate.py $i
	for ((j=1;j<=15;j=$j+1)); do
		echo "$i $j" | tee -a log
		#echo "OPT course"
		{ time python ILP_student_max.py >> log ; } 2>>log 
		#echo "none"
		{ time python approx.py >> log ; } 2>>log 
		#echo "student"
		{ time python studentdeg.py >> log ; } 2>>log 
		#echo "augmenting"
		{ time python augmenting.py >> log ; } 2>>log 
	done
done
