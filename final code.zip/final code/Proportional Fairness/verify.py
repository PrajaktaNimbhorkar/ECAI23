import csv
import sys

from myconfig import *


allotted_students=dict()
cmaxdict=dict() # Upper Quotas of courses
cmindict=dict() # Lower Quotas of courses
calpha_dict=dict()  #Alpha values of courses
cbeta_dict=dict()   #Beta values of courses


#Populate the sets and dictionaries from the data

with open("anon_courses.csv",'r') as cfile:
    cdata= list(csv.reader(cfile,delimiter=',',quotechar='|'))

for row in cdata[1:]:       
    course=row[0]
    uquota=row[1]
    lquota=row[2]
    alpha=row[3]
    beta=row[4]
    cmaxdict[course]=int(uquota)
    cmindict[course]=int(lquota)
    calpha_dict[course]=float(alpha)
    cbeta_dict[course]=float(beta)
    allotted_students[course]=[] 

with open("output.csv",'r') as infile:
    mdata = list(csv.reader(infile,delimiter=',',quotechar='|'))

for row in mdata:
    student = row[0]
    if len(row)==1:
        continue
    course = row[1]

    allotted_students[course].append(student)    


violation_flag=False

for course in allotted_students.keys():
    
    students =allotted_students[course]
    if len(students)==0:
        continue
    num_matched=len(students)

    uquota = cmaxdict[course]
    dept_uquota = cbeta_dict[course]*num_matched
    lquota = cmindict[course]
    dept_lquota = calpha_dict[course]*num_matched
    relaxed_dept_uquota = (cbeta_dict[course]+3.0/lquota)*num_matched
    relaxed_dept_lquota = (calpha_dict[course]-3.0/lquota)*num_matched
    
    if len(students)>uquota:
        print(len(students),uquota,lquota)
        print("UPPER QUOTA ERROR with",course) 
        sys.exit()

    if len(students)<lquota:
        print("LOWER QUOTA ERROR with",course) 
        print(len(students),lquota)
        sys.exit()

 
    for dept in range(1,MAX_DEPT+1):    ## quotas by dept
        num=0
        for s in students:
            if int(s[1:3])==dept:
                num+=1
        if num>dept_uquota:
            violation_flag=True
            if num>relaxed_dept_uquota:
                print("DEPT UPPER ERROR with",course,dept)
                print(num,students,",",dept_uquota,",",relaxed_dept_uquota)
                sys.exit()
        if num<dept_lquota:
            violation_flag=True
            if num<relaxed_dept_lquota:
                print(num,students,",",dept_lquota,",",relaxed_dept_lquota)
                print("DEPT LOWER ERROR with",course,dept)
                sys.exit()

tot_matched = 0
tot_cmatched = 0
for course in allotted_students.keys():
    tot_matched+=len(allotted_students[course])
    if len(allotted_students[course])>0:
        tot_cmatched+=1
    
if violation_flag:
    print("Violation but within bounds")
print("Total number of students matched = ",tot_matched)
print("Total number of courses matched = ",tot_cmatched)
