import csv
import sys

from random import shuffle
from myconfig import *

##fraction of course capacity allotted to any one department or year
COURSE_QUOTA_DEPT = 0.3
COURSE_QUOTA_YEAR = 0.4

with open("anon_studentPreferences.csv",'r') as sfile:
    sdata= list(csv.reader(sfile,delimiter=',',quotechar='|'))

with open("anon_courses.csv",'r') as cfile:
    cdata= list(csv.reader(cfile,delimiter=',',quotechar='|'))


sset = set()    # Set of students
cset = set()    # Set of courses

cdict = dict()  # Lists of students applying to a course
cmaxdict=dict() # Upper Quotas of courses
cmindict=dict() # Lower Quotas of courses
calpha_dict=dict()  #Alpha values of courses
cbeta_dict=dict()   #Beta values of courses
sdegdict=dict() # Degrees of students

allotted_students=dict()    #Lists of students allotted to courses
allotted_courses=dict()     # Lists of courses allotted to students
matched_students=set() # Set of students matched to some course

departments=[]
for i in range(1,MAX_DEPT+1):
    if(i>9):
        departments.append("D"+str(i))
    else:
        departments.append("D0"+str(i))

# Populate the sets and dictionaries from the data

for row in sdata[1:]:
   
    student=row[0]
    courses=row[1:]
    sset.add(student)
    allotted_courses[student]=[]

    sdegdict[student]=len(courses)

    for course in courses:
        cset.add(course)
        if cdict.get(course)==None:
            cdict[course]=[]
        cdict[course].append(student)




for row in cdata[1:]:       
    course=row[0]
    uquota=row[1]
    lquota=row[2]
    alpha=row[3]
    beta=row[4]
    cmaxdict[course]=int(uquota)
    cmindict[course]=int(lquota)
    calpha_dict[course]=float(alpha)
    cbeta_dict[course]=float(beta)
    allotted_students[course]=[] 



def find_augmenting_path(course,dept,visited_students=set(),visited_courses=set()):

    if course in visited_courses:
        return []
    else:
        visited_courses.add(course)

    temp_students=cdict[course]
    success=False
    for student in temp_students:
        if dept==student[0:3] and (student not in visited_students):
            if student not in matched_students:
                success=True
                return [student]
            else:
                visited_students.add(student)
                next_course=allotted_courses[student][0]
                result = find_augmenting_path(next_course,dept,visited_students,visited_courses)
                if len(result)==0:
                    continue
                else:
                    success=True
                    #print(student)
                    #print(next_course)
                    result.append(next_course)
                    result.append(student)
                    return result

    if not success:
        return []
    else:
        print("error!")

def augment(result):
    L=len(result)
    if L<2:
        return
    elif L%2==0:
        print("error!")
    #print(L)
    matched_students.add(result[0])
    matched_students.remove(result[-1])
    for i in range(0,L-1,2):
        #print(result[i],"matches to ",result[i+1])
        student1=result[i]
        course=result[i+1]
        student2=result[i+2]
        allotted_courses[student1].append(course)
        allotted_students[course].append(student1)
        allotted_students[course].remove(student2)
        allotted_courses[student2].remove(course)

# Start iterating over courses
cset=list(cset)
shuffle(cset)
for course in cset:
    dept_dict=dict()
    temp_students = cdict[course]
    temp_matched=dict()
    temp_matched_list=[]
    allotted_students_num=0
    allotted_depts_num = dict()
    cannot_satisfy=0


    for dept in departments:
        allotted_depts_num[dept]=0
        dept_dict[dept]=[]
    ## temp_students contains the list of 
    ## students applying to this course.
    ## from this, we need to remove the 
    ## students who are already matched to 
    ## 1  course        
    ctr=0
    avl=[]
    for student in temp_students:
        s=1
        if (len(allotted_courses[student]))==0:
            student_dept = student[0:3]
            if dept_dict.get(student_dept)==None:
                dept_dict[student_dept]=[student]
            else:
                dept_dict[student_dept].append(student)
            temp_matched[student]=0
            ctr+=1
            avl.append(student)     
            ## if the student can match to a 
            ## course then add it to
            ## the lists of students we consider

    #print(course," has ",ctr," students available to match")
    #print(sorted(avl))
    uquota=cmaxdict[course]
    lquota=cmindict[course]

    dept_uquota = lquota*cbeta_dict[course]    
    dept_lquota = lquota*calpha_dict[course]
    
    cannot_satisfy=0

    while(cannot_satisfy==0 and allotted_students_num+lquota<=uquota):
        ##Match students to satisfy lower bounds of classes
        ## Each iteration of this while loop constructs a
        ## hyperedge of size lquota

        if allotted_students_num>=uquota:
            break

        hyperedge=set()
        hyperedge_deptsize=dict()
                
        for dept in departments:
            shuffle(dept_dict[dept])
            hyperedge_deptsize[dept]=0
            
            temp_list = [ (sdegdict[student],student) for student in dept_dict[dept] ]
            temp_list.sort()

            for degree,student in temp_list:
                if hyperedge_deptsize[dept]>= dept_lquota-3:
                    break
                if temp_matched[student]==1:
                    continue

                hyperedge_deptsize[dept]+=1
                hyperedge.add(student)

            while hyperedge_deptsize[dept]<dept_lquota-3:
                visited_students=set(hyperedge)
                result=find_augmenting_path(course,dept,visited_students)
                if len(result)>0:
                    #for x in result:
                    #    if x[0]=='H':
                    #        print(allotted_students[x])
                    #    else:
                    #        print(allotted_courses[x])
                    augment(result)
                    #print(result)
                    student = result[-1]
                    hyperedge.add(student)
                    hyperedge_deptsize[dep]+=1
                else:
                    cannot_satisfy=1
                    #print("sorry cannot satisfy",dept)
                    break

            if hyperedge_deptsize[dept]<dept_lquota-3:
                cannot_satisfy=1
                #print("sorry cannot satisfy",dept)
                break

        if cannot_satisfy==1 or len(hyperedge)>lquota:
            break

        ##Match students to ensure that hyperedge has size = l
        
        for dept in departments:
            if len(hyperedge)==lquota:
                break

            if allotted_students_num+len(hyperedge)>=uquota:
                cannot_satisfy=1
                break
            
            shuffle(dept_dict[dept])
            temp_list = [ (sdegdict[student],student) for student in dept_dict[dept] ]
            temp_list.sort()

            for degree,student in temp_list:
                if hyperedge_deptsize[dept]+1>dept_uquota+3 or len(hyperedge)==lquota:
                    break
                if temp_matched[student]==1 or student in hyperedge:
                    continue
                hyperedge.add(student)
                hyperedge_deptsize[dept]+=1
            
            while hyperedge_deptsize[dept]<=dept_uquota+2 and len(hyperedge)<lquota:
                visited_students=set(hyperedge)
                result=find_augmenting_path(course,dept,visited_students)
                if len(result)>0:
                    #for x in result:
                    #    if x[0]=='H':
                    #        print(allotted_students[x])
                    #    else:
                    #        print(allotted_courses[x])
                    augment(result)
                    #print(result)
                    student = result[-1]
                    hyperedge.add(student)
                    hyperedge_deptsize[dept]+=1
                else:
                    #print("sorry cannot satisfy",dept)
                    break
            if hyperedge_deptsize[dept]>dept_uquota+3:
                cannot_satisfy=1
        
        if len(hyperedge)!=lquota or cannot_satisfy==1:
            cannot_satisfy=1
            continue
       ## Match the students to courses now
        #print(course,"can be satisfied!",len(temp_matched_list))
        for student in hyperedge:
            temp_matched[student]=1
            allotted_students_num+=1
            allotted_courses[student].append(course)
            allotted_students[course].append(student)
            matched_students.add(student)
                       

tot=0
for course in cset:
    tot+=cmaxdict[course]

tot_matched=0
cmatched_set=set()

for student in sset:
    tot_matched+=len(allotted_courses[student])
    for course in allotted_courses[student]:
        cmatched_set.add(course)



#print("Total students available : ",len(sset))
#print("Total students matched : ",tot_matched)
print(tot_matched)
#print("Total courses matched : ",len(cmatched_set))



with open('output.csv','w',newline='') as ofile:
    writer = csv.writer(ofile)
    for student in sset:
        writer.writerow([student]+allotted_courses[student])

