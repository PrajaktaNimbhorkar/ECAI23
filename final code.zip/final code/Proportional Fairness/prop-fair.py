import csv
import sys

from random import shuffle
from generator.myconfig import *

##fraction of course capacity allotted to any one department or year
COURSE_QUOTA_DEPT = 0.3
COURSE_QUOTA_YEAR = 0.4

with open("anon_studentPreferences.csv",'r') as sfile:
    sdata= list(csv.reader(sfile,delimiter=',',quotechar='|'))

with open("anon_courses.csv",'r') as cfile:
    cdata= list(csv.reader(cfile,delimiter=',',quotechar='|'))


sset = set()    # Set of students
cset = set()    # Set of courses

cdict = dict()  # Lists of students applying to a course
cmaxdict=dict() # Quotas of courses


allotted_courses=dict() # Lists of courses allotted to students


departments=[]
for i in range(1,MAX_DEPT+1):
    if(i>9):
        departments.append("D"+str(i))
    else:
        departments.append("D0"+str(i))

# Populate the sets and dictionaries from the data

for row in sdata[1:]:
   
    student=row[0]
    courses=row[1:]
    sset.add(student)
    allotted_courses[student]=[]
    

    for course in courses:
        cset.add(course)
        if cdict.get(course)==None:
            cdict[course]=[]
        cdict[course].append(student)

for row in cdata[1:]:
    
    course=row[0]
    quota=row[1]
    cmaxdict[course]=int(quota)


# Start iterating over courses
cset=list(cset)
shuffle(cset)
for course in cset:
    dept_dict=dict()
    temp_students = cdict[course]
    temp_matched=dict()
    temp_matched_list=[]
    allotted_students_num=0
    allotted_depts_num = dict()
    cannot_satisfy=0


    for dept in departments:
        allotted_depts_num[dept]=0
        dept_dict[dept]=[]
   ## temp_students contains the list of 
    ## students applying to this course.
    ## from this, we need to remove the 
    ## students who are already matched to 
    ## 1  course        
    ctr=0
    avl=[]
    for student in temp_students:
        s=1
        if (len(allotted_courses[student]))==0:
            student_dept = student[0:3]
            if dept_dict.get(student_dept)==None:
                dept_dict[student_dept]=[student]
            else:
                dept_dict[student_dept].append(student)
            temp_matched[student]=0
            ctr+=1
            avl.append(student)     
            ## if the student can match to a 
            ## course then add it to
            ## the lists of students we consider

    #print(course," has ",ctr," students available to match")
    #print(sorted(avl))
    uquota=cmaxdict[course]
    dept_uquota = int(COURSE_QUOTA_DEPT*uquota)

    lquota=COURSE_QUOTA_LOWER
    dept_lquota = COURSE_QUOTA_DEPT_LOWER
    
    ##Match students to satisfy lower bounds of classes
    shuffle(departments)
    for dept in departments:
        shuffle(dept_dict[dept])
        for student in dept_dict[dept]:
            if allotted_depts_num[dept]==dept_lquota or allotted_students_num>=uquota:
                break
            if temp_matched[student]==1:
                continue
            allotted_depts_num[dept]+=1
            allotted_students_num+=1
            temp_matched[student]=1
            temp_matched_list.append(student)

        if allotted_depts_num[dept]<dept_lquota:
            cannot_satisfy=1
            #print("sorry cannot satisfy",dept)
            break

    if cannot_satisfy==1:
        continue

    ##Match students to satisfy lower bounds of courses
    
    shuffle(departments)
    for dept in departments:
        if allotted_students_num>=lquota:
            break
        shuffle(dept_dict[dept])
        for student in dept_dict[dept]:
            if allotted_depts_num[dept]==dept_uquota or allotted_students_num>=lquota:
                break
            if temp_matched[student]==1:
                continue
            allotted_depts_num[dept]+=1
            allotted_students_num+=1
            temp_matched[student]=1
            temp_matched_list.append(student)
        if allotted_students_num>=lquota:
            break

    if allotted_students_num<lquota:
        cannot_satisfy=1
        break
    ## Match the students to courses now
    #print(course,"can be satisfied!",len(temp_matched_list))
    for student in temp_matched_list:
        allotted_courses[student].append(course)    
        

tot=0
for course in cset:
    tot+=cmaxdict[course]

tot_matched=0
cmatched_set=set()

for student in sset:
    tot_matched+=len(allotted_courses[student])
    for course in allotted_courses[student]:
        cmatched_set.add(course)



print("Total students available : ",len(sset))
print("Total students matched : ",tot_matched)
print("Total courses matched : ",len(cmatched_set))



with open('output.csv','w',newline='') as ofile:
    writer = csv.writer(ofile)
    for student in sset:
        writer.writerow([student]+allotted_courses[student])

