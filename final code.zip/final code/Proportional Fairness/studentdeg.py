import csv
import sys

from random import shuffle
from myconfig import *

##fraction of course capacity allotted to any one department or year
COURSE_QUOTA_DEPT = 0.3
COURSE_QUOTA_YEAR = 0.4

with open("anon_studentPreferences.csv",'r') as sfile:
    sdata= list(csv.reader(sfile,delimiter=',',quotechar='|'))

with open("anon_courses.csv",'r') as cfile:
    cdata= list(csv.reader(cfile,delimiter=',',quotechar='|'))


sset = set()    # Set of students
cset = set()    # Set of courses

cdict = dict()  # Lists of students applying to a course
cmaxdict=dict() # Upper Quotas of courses
cmindict=dict() # Lower Quotas of courses
calpha_dict=dict()  #Alpha values of courses
cbeta_dict=dict()   #Beta values of courses
sdegdict=dict() # Degrees of students

allotted_students=dict()    #Lists of students allotted to courses
allotted_courses=dict()     # Lists of courses allotted to students


departments=[]
for i in range(1,MAX_DEPT+1):
    if(i>9):
        departments.append("D"+str(i))
    else:
        departments.append("D0"+str(i))

# Populate the sets and dictionaries from the data

for row in sdata[1:]:
   
    student=row[0]
    courses=row[1:]
    sset.add(student)
    allotted_courses[student]=[]

    sdegdict[student]=len(courses)

    for course in courses:
        cset.add(course)
        if cdict.get(course)==None:
            cdict[course]=[]
        cdict[course].append(student)




for row in cdata[1:]:       
    course=row[0]
    uquota=row[1]
    lquota=row[2]
    alpha=row[3]
    beta=row[4]
    cmaxdict[course]=int(uquota)
    cmindict[course]=int(lquota)
    calpha_dict[course]=float(alpha)
    cbeta_dict[course]=float(beta)
    allotted_students[course]=[] 



# Start iterating over courses
cset=list(cset)
shuffle(cset)
for course in cset:
    dept_dict=dict()
    temp_students = cdict[course]
    temp_matched=dict()
    temp_matched_list=[]
    allotted_students_num=0
    allotted_depts_num = dict()
    cannot_satisfy=0


    for dept in departments:
        allotted_depts_num[dept]=0
        dept_dict[dept]=[]
    ## temp_students contains the list of 
    ## students applying to this course.
    ## from this, we need to remove the 
    ## students who are already matched to 
    ## 1  course        
    ctr=0
    avl=[]
    for student in temp_students:
        s=1
        if (len(allotted_courses[student]))==0:
            student_dept = student[0:3]
            if dept_dict.get(student_dept)==None:
                dept_dict[student_dept]=[student]
            else:
                dept_dict[student_dept].append(student)
            temp_matched[student]=0
            ctr+=1
            avl.append(student)     
            ## if the student can match to a 
            ## course then add it to
            ## the lists of students we consider

    #print(course," has ",ctr," students available to match")
    #print(sorted(avl))
    uquota=cmaxdict[course]
    lquota=cmindict[course]

    dept_uquota = lquota*cbeta_dict[course]    
    dept_lquota = lquota*calpha_dict[course]
    
    cannot_satisfy=0

    while(cannot_satisfy==0 and allotted_students_num+lquota<=uquota):
        ##Match students to satisfy lower bounds of classes
        ## Each iteration of this while loop constructs a
        ## hyperedge of size lquota

        if allotted_students_num>=uquota:
            break

        hyperedge=set()
        hyperedge_deptsize=dict()
                
        for dept in departments:
            shuffle(dept_dict[dept])
            hyperedge_deptsize[dept]=0
            
            temp_list = [ (sdegdict[student],student) for student in dept_dict[dept] ]
            temp_list.sort()

            for degree,student in temp_list:
                if hyperedge_deptsize[dept]>= dept_lquota-3:
                    break
                if temp_matched[student]==1:
                    continue

                hyperedge_deptsize[dept]+=1
                hyperedge.add(student)


            if hyperedge_deptsize[dept]<dept_lquota-3:
                cannot_satisfy=1
                #print("sorry cannot satisfy",dept)
                break

        if cannot_satisfy==1 or len(hyperedge)>lquota:
            break

        ##Match students to ensure that hyperedge has size = l
        
        for dept in departments:
            if len(hyperedge)==lquota:
                break

            if allotted_students_num+len(hyperedge)>=uquota:
                cannot_satisfy=1
                break
            
            shuffle(dept_dict[dept])
            temp_list = [ (sdegdict[student],student) for student in dept_dict[dept] ]
            temp_list.sort()

            for degree,student in temp_list:
                if hyperedge_deptsize[dept]+1>dept_uquota+3 or len(hyperedge)==lquota:
                    break
                if temp_matched[student]==1 or student in hyperedge:
                    continue
                hyperedge.add(student)
                hyperedge_deptsize[dept]+=1

        if len(hyperedge)!=lquota or cannot_satisfy==1:
            cannot_satisfy=1
            continue

        ## Match the students to courses now
        #print(course,"can be satisfied!",len(temp_matched_list))
        for student in hyperedge:
            temp_matched[student]=1
            allotted_students_num+=1
            allotted_courses[student].append(course)    
            

tot=0
for course in cset:
    tot+=cmaxdict[course]

tot_matched=0
cmatched_set=set()

for student in sset:
    tot_matched+=len(allotted_courses[student])
    for course in allotted_courses[student]:
        cmatched_set.add(course)



#print("Total students available : ",len(sset))
print(tot_matched)
#print("Total students matched : ",tot_matched)
#print("Total courses matched : ",len(cmatched_set))



with open('output.csv','w',newline='') as ofile:
    writer = csv.writer(ofile)
    for student in sset:
        writer.writerow([student]+allotted_courses[student])

