import csv
import sys

from myconfig import *


cmaxdict=dict()
allotted_students=dict()

with open("anon_courses.csv",'r') as cfile:
    cdata= list(csv.reader(cfile,delimiter=',',quotechar='|'))

for row in cdata[1:]: 
    course=row[0]
    quota=row[1]
    
    cmaxdict[course]=int(quota)
    allotted_students[course]=[]

print(len(cmaxdict.keys()))
with open("output.csv",'r') as infile:
    mdata = list(csv.reader(infile,delimiter=',',quotechar='|'))

for row in mdata:
    student = row[0]
    if len(row)==1:
        continue
    course = row[1]

    allotted_students[course].append(student)    

print(len(mdata))

for course in allotted_students.keys():
    
    students =allotted_students[course]
    if len(students)==0:
        continue
    uquota = cmaxdict[course]
    dept_uquota = int(uquota * COURSE_QUOTA_DEPT)
    lquota = COURSE_QUOTA_LOWER
    dept_lquota = COURSE_QUOTA_DEPT_LOWER
    if len(students)>uquota:
       print("UPPER QUOTA ERROR with",course) 
       sys.exit()

    if len(students)<lquota:
       print("LOWER QUOTA ERROR with",course) 
       sys.exit()

 
    for dept in range(1,MAX_DEPT+1):    ## quotas by dept
        num=0
        for s in students:
            if int(s[1:3])==dept:
                num+=1
        if num>dept_uquota:
            print("DEPT UPPER ERROR with",course,dept)
            sys.exit()
        if num<dept_lquota:
            print("DEPT LOWER ERROR with",course,dept)
            sys.exit()

tot_matched = 0
tot_cmatched = 0
for course in allotted_students.keys():
    tot_matched+=len(allotted_students[course])
    if len(allotted_students[course])>0:
        tot_cmatched+=1
    
print("Total number of students matched = ",tot_matched)
print("Total number of courses matched = ",tot_cmatched)
