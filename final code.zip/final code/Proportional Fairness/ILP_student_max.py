import cplex
import csv
import sys
import re

from cplex.exceptions import CplexError
from myconfig import *

with open("anon_studentPreferences.csv",'r') as sfile:
        sdata= list(csv.reader(sfile,delimiter=',',quotechar='|'))

with open("anon_courses.csv",'r') as cfile:
        cdata= list(csv.reader(cfile,delimiter=',',quotechar='|'))



cdict = dict()  # Lists of students applying to a course
cmaxdict=dict() # Upper Quotas of courses
cmindict=dict() # Lower Quotas of courses
calpha_dict=dict()  #Alpha values of courses
cbeta_dict=dict()   #Beta values of courses
sdict=dict()        #adjacency of students
courses=[]      #list of courses


edges=[]
course_vars=[]
# Populate the sets and dictionaries from the data

for row in cdata[1:]:       
    course=row[0]
    uquota=row[1]
    lquota=row[2]
    alpha=row[3]
    beta=row[4]
    cmaxdict[course]=int(uquota)
    cmindict[course]=int(lquota)
    calpha_dict[course]=float(alpha)
    cbeta_dict[course]=float(beta)
    courses.append(course)
    course_vars.append(course+"total")

for row in sdata[1:]:
    student=row[0]
    student_courses=row[1:]
    if len(courses)==0:
        continue

    sdict[student]=student_courses 
    for course in student_courses:
        if cdict.get(course)==None:
                cdict[course]=[]
        cdict[course].append(student)

        ## Variables are (post,type) pairs
    for course in student_courses:
        edges.append(student+course)


## Convert to a set 


### Now that we have the data, we can start 
### setting up the ILP


## First the variables.

#variable as to whether or not the course is satisfied


my_obj  = [1.0 for e in edges]+ [0.0 for c in courses] +[0.0 for c in course_vars]  ## not considering weights in obj function
my_ub   = [1.0 for e in edges]+ [1.0 for c in courses] +[NUMBER_STUDENTS*MAX_DEPT*1.0 for c in course_vars]
                                                                ## upper bound is the number of students from this type
my_lb   = [0.0 for e in edges]+ [0.0 for c in courses] +[0.0 for c in course_vars]
 
my_ctype=""
for t in edges+courses+course_vars:
        my_ctype+='I'               ##all variables are integers
        
my_colnames=edges+courses+course_vars

### Now, the constraints. First we encode the 
### course constraints. 

rows=[]
my_rhs=[]
my_sense=""
my_rownames=[]
row_counter=1

#print(edges)
#print(courses,flush=True)

#print("Number of edges is ",len(edges))

###Start iterating over courses
for course in cdict.keys():
        ## First, the overall quota and setting the course_var to be number of
        ## students matched so far.
        constraint1=[ [], []]
        constraint2=[ [], []]
        constraint3=[ [], []]

        constraint_non_empty=False
        
        students = cdict[course]

        if len(students)>0:
                constraint_non_empty=True
        
        constraint1[0]= [student+course for student in students]
        constraint1[1]= [1.0 for i in range(len(students))]

        #constraint1[0].append(course)
        #constraint1[1].append(-1.0*cmaxdict[course])
        
        if constraint_non_empty:
                my_rhs.append(cmaxdict[course])
                my_sense+='L'
                rows.append(constraint1)
                my_rownames.append("r"+str(row_counter))
                row_counter+=1

        constraint2[0]= [student+course for student in students]
        constraint2[1]= [1.0 for i in range(len(students))]

        constraint2[0].append(course)
        constraint2[1].append(-1.0*cmindict[course])
        my_rhs.append(0)
        my_sense+='G'
        rows.append(constraint2)
        my_rownames.append("r"+str(row_counter))
        row_counter+=1

 
        constraint3[0]= [student+course for student in students]
        constraint3[1]= [1.0 for i in range(len(students))]

        constraint3[0].append(course+"total")
        constraint3[1].append(-1.0)
        my_rhs.append(0)
        my_sense+='E'
        rows.append(constraint3)
        my_rownames.append("r"+str(row_counter))
        row_counter+=1       

        for dept in range(1,MAX_DEPT+1):        ## quotas by dept
                constraint1=[[], []]
                constraint2=[[], []]
                
                constraint1[0] = [student+course for student in students if int(student[1:3])==dept]
                constraint1[1] = [1.0 for i in range(len(constraint1[0]))]
                constraint1[0].append(course+"total")
                constraint1[1].append(-1.0*cbeta_dict[course])

                if len(constraint1[0])>0:
                        my_rhs.append(0)
                        my_sense+='L'
                        rows.append(constraint1)
                        my_rownames.append("r"+str(row_counter))
                        row_counter+=1

                constraint2[0] = [student+course for student in students if int(student[1:3])==dept]
                constraint2[1] = [1.0 for i in range(len(constraint2[0]))]
                constraint2[0].append(course+"total")
                constraint2[1].append(-1.0*calpha_dict[course])

                
                
                my_rhs.append(0)
                my_sense+='G'
                rows.append(constraint2)
                my_rownames.append("r"+str(row_counter))
                row_counter+=1


##### Now add the applicant constraints
for student in sdict.keys():        
        Hconstraint=[[], []]
        
        courses = sdict[student]

        h_list=[student+course for course in courses]
        
        if len(h_list)>0:
                Hconstraint_non_empty=True

        else:
                Hconstraint_non_empty=False
        Hconstraint[0] = h_list
        Hconstraint[1] = [1.0 for i in range(len(h_list))]


        if Hconstraint_non_empty:
                my_rhs.append(1)
                my_sense+='L'
                rows.append(Hconstraint)
                my_rownames.append("r"+str(row_counter))
                row_counter+=1
        
    



prob = cplex.Cplex()
prob.set_log_stream(None)
prob.set_warning_stream(None)
prob.set_results_stream(None)



#sys.exit()

#print(my_ctype)

#print(my_colnames)

#print(my_rhs)

#print(rows)


prob.objective.set_sense(prob.objective.sense.maximize)

#print(len(my_obj),len(my_lb),len(my_ub),len(my_ctype),len(my_colnames))
prob.variables.add(obj=my_obj, lb=my_lb, ub=my_ub, types=my_ctype,
                   names=my_colnames)

      
prob.linear_constraints.add(lin_expr=rows, senses=my_sense,
                            rhs=my_rhs, names=my_rownames)
try:
        prob.solve()
except CplexError as exc:
        print(exc)
        sys.exit()
        
        #show_output(prob)
soln = prob.solution.get_values()


allotted_courses=dict()

for student in sdict.keys():
        allotted_courses[student]=[]
                

for j in range(len(edges)):
        
        student_course = re.split('([D,M,H])',edges[j])

        for i in range(1,len(student_course)):
                if student_course[i-1]=='D':
                        student='D'+student_course[i]
                elif student_course[i-1]=='H':
                        course='H'+student_course[i]
                elif student_course[i-1]=='M':
                        course='M'+student_course[i]
        course_type=course[0]
        matched= round(soln[j])             ## if there is some student matched from this type
        if matched<=0:
                continue                                ## then arbitrarily pick one student and match  

        allotted_courses[student].append(course)        
                


tot_matched=0
cmatched_set=set()


for student in allotted_courses.keys():
        tot_matched+=len(allotted_courses[student])
        for course in allotted_courses[student]:
            cmatched_set.add(course)

#print("Total seats available : ",tot)
#print("Total students matched : ", tot_matched)
#print("Total courses matched : ", len(cmatched_set))
print(tot_matched)


with open('output.csv','w',newline='') as ofile:
        writer = csv.writer(ofile)
        for student in allotted_courses.keys():
                writer.writerow([student]+allotted_courses[student])

