import random
import csv
import os
import sys

#random.seed(a=1000)

from myconfig import *
MAX_COURSE=int(sys.argv[1])

## Create courses with random quotas

with open(os.path.join( os.getcwd(), '.','anon_courses.csv'),'w',newline='') as ofile:
    writer=csv.writer(ofile)
    writer.writerow(["#","MAX","MIN","alpha","beta"])
    for ID in range(1,NUMBER_COURSES+1):
        course='H'+str(ID)
        uquota = random.randint(1,100)
        lquota = random.randint(1,20)
        lquota = min(lquota,uquota)
        writer.writerow([course,uquota,lquota,0.5/MAX_DEPT,2.0/MAX_DEPT]) 

sdict=dict()
## list of students and their courses

for d in range(1,MAX_DEPT+1):

    if d<10:
        dept='0'+str(d)
    else:
        dept=str(d)

    for ID in range(1,NUMBER_STUDENTS+1): 
    ## Assume equal distribution of students 
    ## across departments
    ## Set the roll number of student
        
        student = 'D'+dept+'B'+str(ID)
        
        num_courses = random.randint(1,MAX_COURSE)

        courses_set=set()
        
        course_ID=random.randint(1,NUMBER_COURSES)
        courses_set.add('H'+str(course_ID))

        for i in range(num_courses-1):
            course_ID=random.randint(1,NUMBER_COURSES)
            courses_set.add('H'+str(course_ID))

        sdict[student]=list(courses_set)


with open(os.path.join( os.getcwd(), '.', 'anon_studentPreferences.csv'), 'w',newline='') as ofile:
    
    writer=csv.writer(ofile)
    writer.writerow(["#","Preferences"])
    for student in sdict.keys():
        writer.writerow([student]+sdict[student])
    






